#include "dglab_controller.h"
#include "websocket_client.h"
#include "dglab_protocol.h"
#include "waveform_manager.h"
#include <android/log.h>
#include <chrono>

#define LOG_TAG "DGLab-CTRL"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace DGLab {

DGLabController::DGLabController()
    : wsClient_(std::make_unique<WebSocketClient>())
    , protocol_(std::make_unique<Protocol>())
    , waveformManager_(std::make_unique<WaveformManager>()) {
    
    stats_.connectionStart = std::chrono::steady_clock::now();
    stats_.lastActivity = std::chrono::steady_clock::now();
}

DGLabController::~DGLabController() {
    disconnect();
}

bool DGLabController::initialize(const ControllerConfig& config) {
    config_ = config;
    
    // 设置 WebSocket 回调
    wsClient_->setOnMessage([this](const std::string& msg) {
        onWebSocketMessage(msg);
    });
    
    wsClient_->setOnStateChange([this](ConnectionState state) {
        switch (state) {
            case ConnectionState::CONNECTED:
                updateState(ControllerState::CONNECTED);
                break;
            case ConnectionState::BOUND:
                updateState(ControllerState::BOUND);
                break;
            case ConnectionState::DISCONNECTED:
                updateState(ControllerState::IDLE);
                break;
            case ConnectionState::ERROR:
                updateState(ControllerState::ERROR);
                break;
            default:
                break;
        }
    });
    
    wsClient_->setOnError([this](const std::string& err) {
        onWebSocketError(err);
    });
    
    LOGI("Controller initialized, URI: %s", config_.serverUri.c_str());
    return true;
}

bool DGLabController::connect() {
    if (state_ == ControllerState::CONNECTED || state_ == ControllerState::BOUND) {
        return true;
    }
    
    updateState(ControllerState::CONNECTING);
    
    {
        std::lock_guard<std::mutex> lk(statsMutex_);
        stats_.connectionAttempts++;
    }
    
    if (wsClient_->connect(config_.serverUri)) {
        LOGI("Connecting to %s", config_.serverUri.c_str());
        return true;
    }
    
    updateState(ControllerState::ERROR);
    return false;
}

void DGLabController::disconnect() {
    wsClient_->disconnect();
    updateState(ControllerState::IDLE);
    LOGI("Disconnected");
}

bool DGLabController::reconnect() {
    disconnect();
    std::this_thread::sleep_for(std::chrono::milliseconds(500));
    return connect();
}

bool DGLabController::sendEffect(const EffectRequest& request) {
    if (!isBound()) return false;
    
    bool sent = false;
    
    if (request.syncChannels) {
        // 双通道同步：先清空、再灌波形、最后设强度
        wsClient_->sendMessage(protocol_->createClearMessage(Channel::A));
        wsClient_->sendMessage(protocol_->createClearMessage(Channel::B));
        
        auto chunksA = waveformManager_->getWaveformChunks(request.waveformId, 100);
        auto chunksB = chunksA;
        
        for (const auto& chunk : chunksA) {
            wsClient_->sendMessage(protocol_->createPulseMessage(Channel::A, chunk));
        }
        for (const auto& chunk : chunksB) {
            wsClient_->sendMessage(protocol_->createPulseMessage(Channel::B, chunk));
        }
        
        wsClient_->sendMessage(protocol_->createStrengthMessage(Channel::A, request.intensityA));
        wsClient_->sendMessage(protocol_->createStrengthMessage(Channel::B, request.intensityB));
        sent = true;
    } else {
        // 单通道
        sent = sendWaveformSingleChannel(1, request.waveformId, request.intensityA);
        sent |= sendWaveformSingleChannel(2, request.waveformId, request.intensityB);
    }
    
    if (sent) {
        updateStats(true, false);
        std::lock_guard<std::mutex> lk(statsMutex_);
        stats_.lastActivity = std::chrono::steady_clock::now();
        stats_.messagesSent += 4; // clear x2 + pulse x2 + strength x2 ≈
    }
    
    return sent;
}

bool DGLabController::setStrength(int channelA, int channelB) {
    if (!isBound()) return false;
    
    wsClient_->sendMessage(protocol_->createStrengthMessage(Channel::A, channelA));
    wsClient_->sendMessage(protocol_->createStrengthMessage(Channel::B, channelB));
    updateStats(true, false);
    return true;
}

bool DGLabController::setStrengthA(int strength) {
    if (!isBound()) return false;
    wsClient_->sendMessage(protocol_->createStrengthMessage(Channel::A, strength));
    updateStats(true, false);
    return true;
}

bool DGLabController::setStrengthB(int strength) {
    if (!isBound()) return false;
    wsClient_->sendMessage(protocol_->createStrengthMessage(Channel::B, strength));
    updateStats(true, false);
    return true;
}

bool DGLabController::stopAllEffects() {
    if (!isBound()) return false;
    
    wsClient_->sendMessage(protocol_->createStrengthMessage(Channel::A, 0));
    wsClient_->sendMessage(protocol_->createStrengthMessage(Channel::B, 0));
    wsClient_->sendMessage(protocol_->createClearMessage(Channel::A));
    wsClient_->sendMessage(protocol_->createClearMessage(Channel::B));
    updateStats(true, false);
    return true;
}

bool DGLabController::clearChannel(int channel) {
    if (!isBound()) return false;
    wsClient_->sendMessage(protocol_->createClearMessage(
        channel == 1 ? Channel::A : Channel::B));
    updateStats(true, false);
    return true;
}

bool DGLabController::sendWaveform(const std::string& waveId, int intensityA, int intensityB) {
    if (!isBound()) return false;
    
    // 清空
    wsClient_->sendMessage(protocol_->createClearMessage(Channel::A));
    wsClient_->sendMessage(protocol_->createClearMessage(Channel::B));
    
    auto chunksA = waveformManager_->getWaveformChunks(waveId, 100);
    
    for (const auto& chunk : chunksA) {
        wsClient_->sendMessage(protocol_->createPulseMessage(Channel::A, chunk));
    }
    for (const auto& chunk : chunksA) {
        wsClient_->sendMessage(protocol_->createPulseMessage(Channel::B, chunk));
    }
    
    wsClient_->sendMessage(protocol_->createStrengthMessage(Channel::A, intensityA));
    wsClient_->sendMessage(protocol_->createStrengthMessage(Channel::B, intensityB));
    
    updateStats(true, false);
    return true;
}

bool DGLabController::sendWaveformSingleChannel(int channel, const std::string& waveId, int intensity) {
    if (!isBound()) return false;
    
    Channel ch = (channel == 1) ? Channel::A : Channel::B;
    
    wsClient_->sendMessage(protocol_->createClearMessage(ch));
    
    auto chunks = waveformManager_->getWaveformChunks(waveId, 100);
    for (const auto& chunk : chunks) {
        wsClient_->sendMessage(protocol_->createPulseMessage(ch, chunk));
    }
    
    wsClient_->sendMessage(protocol_->createStrengthMessage(ch, intensity));
    
    updateStats(true, false);
    return true;
}

bool DGLabController::enableSync(bool) {
    // syncChannels 标志由调用者在 EffectRequest 中自行控制
    return true;
}

bool DGLabController::isSyncEnabled() const {
    return true;
}

ControllerState DGLabController::getState() const { return state_; }
bool DGLabController::isConnected() const { return state_ >= ControllerState::CONNECTED; }
bool DGLabController::isBound() const { return state_ >= ControllerState::BOUND; }

std::string DGLabController::getServerUri() const { return config_.serverUri; }
std::string DGLabController::getTargetId() const { return wsClient_->getTargetId(); }
std::string DGLabController::getClientId() const { return wsClient_->getGeneratedClientId(); }

ControllerStats DGLabController::getStats() const {
    std::lock_guard<std::mutex> lk(statsMutex_);
    return stats_;
}

bool DGLabController::loadWaveform(const std::string& filePath) {
    return waveformManager_->loadWaveform(filePath);
}

bool DGLabController::loadWaveformFromString(const std::string& id, const std::string& jsonContent) {
    return waveformManager_->loadWaveformFromString(id, jsonContent);
}

std::vector<std::string> DGLabController::getAvailableWaveforms() const {
    return waveformManager_->getAvailableWaveforms();
}

void DGLabController::setOnStateChange(std::function<void(ControllerState)> cb) { onStateChange_ = cb; }
void DGLabController::setOnError(std::function<void(const std::string&)> cb) { onError_ = cb; }
void DGLabController::setOnMessage(std::function<void(const std::string&)> cb) { onMessage_ = cb; }

void DGLabController::updateConfig(const ControllerConfig& config) {
    config_ = config;
}

ControllerConfig DGLabController::getConfig() const { return config_; }

std::string DGLabController::controllerStateToString(ControllerState state) {
    switch (state) {
        case ControllerState::IDLE: return "空闲";
        case ControllerState::CONNECTING: return "连接中...";
        case ControllerState::CONNECTED: return "已连接";
        case ControllerState::BOUND: return "已绑定";
        case ControllerState::ACTIVE: return "运行中";
        case ControllerState::ERROR: return "错误";
        default: return "未知";
    }
}

ControllerState DGLabController::stringToControllerState(const std::string& str) {
    if (str == "空闲") return ControllerState::IDLE;
    if (str == "连接中...") return ControllerState::CONNECTING;
    if (str == "已连接") return ControllerState::CONNECTED;
    if (str == "已绑定") return ControllerState::BOUND;
    if (str == "运行中") return ControllerState::ACTIVE;
    if (str == "错误") return ControllerState::ERROR;
    return ControllerState::IDLE;
}

void DGLabController::updateState(ControllerState newState) {
    state_ = newState;
    if (onStateChange_) onStateChange_(newState);
}

void DGLabController::updateStats(bool sent, bool received) {
    std::lock_guard<std::mutex> lk(statsMutex_);
    if (sent) stats_.messagesSent++;
    if (received) stats_.messagesReceived++;
    stats_.lastActivity = std::chrono::steady_clock::now();
}

void DGLabController::handleError(const std::string& error) {
    LOGE("Controller error: %s", error.c_str());
    updateState(ControllerState::ERROR);
    if (onError_) onError_(error);
}

void DGLabController::onWebSocketMessage(const std::string& message) {
    updateStats(false, true);
    if (onMessage_) onMessage_(message);
}

void DGLabController::onWebSocketStateChange(int state) {
    // handled via lambda in initialize
}

void DGLabController::onWebSocketError(const std::string& error) {
    handleError(error);
}

} // namespace DGLab