#pragma once
#include <string>
#include <vector>
#include <memory>
#include <atomic>
#include <mutex>
#include <functional>
#include <chrono>

namespace DGLab {

class WebSocketClient;
class Protocol;
class WaveformManager;

// 控制器配置
struct ControllerConfig {
    std::string serverUri = "ws://192.168.1.100:8080"; // 默认地址
    int defaultStrengthA = 50;
    int defaultStrengthB = 50;
    std::string defaultWaveform = "heartbeat";
    bool autoReconnect = true;
    int reconnectIntervalMs = 5000;
    int heartbeatIntervalMs = 60000;
};

// 控制器状态
enum class ControllerState {
    IDLE,
    CONNECTING,
    CONNECTED,
    BOUND,
    ACTIVE,
    ERROR
};

// 效果请求结构
struct EffectRequest {
    std::string waveformId;
    int intensityA = 50;
    int intensityB = 50;
    int durationMs = 1000;
    bool syncChannels = true;
    std::string source; // "damage", "heartbeat", "environment"
};

// 统计信息
struct ControllerStats {
    int messagesSent = 0;
    int messagesReceived = 0;
    int connectionAttempts = 0;
    int successfulConnections = 0;
    std::chrono::steady_clock::time_point lastActivity;
    std::chrono::steady_clock::time_point connectionStart;
};

// DGLab控制器主类
class DGLabController {
public:
    DGLabController();
    ~DGLabController();
    
    // 初始化和连接管理
    bool initialize(const ControllerConfig& config = {});
    bool connect();
    void disconnect();
    bool reconnect();
    
    // 效果控制
    bool sendEffect(const EffectRequest& request);
    bool setStrength(int channelA, int channelB);
    bool setStrengthA(int strength);
    bool setStrengthB(int strength);
    bool stopAllEffects();
    bool clearChannel(int channel);
    
    // 波形控制
    bool sendWaveform(const std::string& waveId, int intensityA, int intensityB);
    bool sendWaveformSingleChannel(int channel, const std::string& waveId, int intensity);
    
    // 通道同步
    bool enableSync(bool enable);
    bool isSyncEnabled() const;
    
    // 状态查询
    ControllerState getState() const;
    bool isConnected() const;
    bool isBound() const;
    
    // 获取信息
    std::string getServerUri() const;
    std::string getTargetId() const;
    std::string getClientId() const;
    ControllerStats getStats() const;
    
    // 波形管理
    bool loadWaveform(const std::string& filePath);
    bool loadWaveformFromString(const std::string& id, const std::string& jsonContent);
    std::vector<std::string> getAvailableWaveforms() const;
    
    // 回调设置
    void setOnStateChange(std::function<void(ControllerState)> callback);
    void setOnError(std::function<void(const std::string&)> callback);
    void setOnMessage(std::function<void(const std::string&)> callback);
    
    // 配置更新
    void updateConfig(const ControllerConfig& config);
    ControllerConfig getConfig() const;
    
    // 工具函数
    static std::string controllerStateToString(ControllerState state);
    static ControllerState stringToControllerState(const std::string& str);
    
private:
    // 内部组件
    std::unique_ptr<WebSocketClient> wsClient_;
    std::unique_ptr<Protocol> protocol_;
    std::unique_ptr<WaveformManager> waveformManager_;
    
    // 状态
    std::atomic<ControllerState> state_{ControllerState::IDLE};
    ControllerConfig config_;
    
    // 统计
    ControllerStats stats_;
    mutable std::mutex statsMutex_;
    
    // 回调
    std::function<void(ControllerState)> onStateChange_;
    std::function<void(const std::string&)> onError_;
    std::function<void(const std::string&)> onMessage_;
    
    // 内部方法
    void updateState(ControllerState newState);
    void updateStats(bool sent, bool received);
    void handleError(const std::string& error);
    
    // 事件处理器
    void onWebSocketMessage(const std::string& message);
    void onWebSocketStateChange(int state);
    void onWebSocketError(const std::string& error);
};

} // namespace DGLab